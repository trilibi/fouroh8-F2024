<?php

class Smath {
  public $numOne = 0;
  public $numTwo = 0;

  public function __construct($numOne = 0, $numTwo = 0) {
    $this->numOne = $numOne;
    $this->numTwo = $numTwo;
  }

  public function add() {
    return $this->numOne + $this->numTwo;
  }

  public function subtract() {
    return $this->numOne - $this->numTwo;
  }

  public function multiply() {
    return $this->numOne * $this->numTwo;
  }

  public function divide() {
    if ($this->numTwo != 0) {
      return intdiv($this->numOne, $this->numTwo);
    } else {
      return 'Division by zero error';
    }
  }

  public function __toString() {
    return "Smaths Completed with {$this->numOne} and {$this->numTwo}";
  }
}

?>

<html>
  <head>
    <title>PHP Form & Class</title>
  </head>
  <body>
    <form action="" method="post">
      <label>Num 1 
        <input name="numOne" value="<?= isset($_POST['numOne']) ? $_POST['numOne'] : '' ?>" />
      </label>  
      <label>Num 2 
        <input name="numTwo" value="<?= isset($_POST['numTwo']) ? $_POST['numTwo'] : '' ?>" />
      </label>  
      <button type="submit" name="calculate">All the Maths</button> 
    </form>

    <?php
    if (isset($_REQUEST['calculate'])) {
      $numOne = isset($_REQUEST['numOne']) ? (int)$_REQUEST['numOne'] : 0;
      $numTwo = isset($_REQUEST['numTwo']) ? (int)$_REQUEST['numTwo'] : 0;
      $maths = new Smath($numOne, $numTwo);

      echo '<pre style="color: navy">Form Request: ' . print_r($_REQUEST, true) . '</pre>';
      echo '<pre style="color: navy">' . print_r($maths, true) . '</pre>';
      echo '<p>The sum is ' . $maths->add() . '</p>';
      echo '<p>The difference is ' . $maths->subtract() . '</p>';
      echo '<p>The product is ' . $maths->multiply() . '</p>';
      echo '<p>The quotient is ' . $maths->divide() . '</p>';
      echo '<p style="color: green">Smaths as string: ' . $maths . '</p>';
    }
    ?>
  </body>
</html>
