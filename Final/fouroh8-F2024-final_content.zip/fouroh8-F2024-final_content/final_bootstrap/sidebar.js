export default function Sidebar() {
  return <div id="sidebar">Bar</div>;
}
